Cybercrime against Businesses, 2005

This zip archive contains tables in individual.csv spreadsheets
from Cybercrime against Businesses, 2005, NCJ 221943.
The full report including text and graphics in .pdf format is available at		
http://www.ojp.usdoj.gov/bjs/abstract/cb05.htm


cb05t01.csv	Table 1. Prevalence of computer security incidents, types of offenders, and reporting to law enforcement, 2005
cb05t02.csv	Table 2. Universe, sample, and response, by business size and selected industries, 2005
cb05t03.csv	Table 3. Prevalence of computer security incidents among businesses, by type of incident, 2005
cb05t04.csv	Table 4. Detailed characteristics of selected types of computer security incidents, by type, 2005
cb05t05.csv	Table 5. Number of computer security incidents, by type of incident, 2005
cb05t06.csv	Table 6. Monetary loss incurred from computer security incidents, by type of incident, 2005
cb05t07.csv	Table 7. System downtime caused by computer security incidents, by type of incident, 2005
cb05t08.csv	Table 8. Number of computer security incidents and amount of monetary loss and system downtime, by type of incident, 2005
cb05t09.csv	Table 9. Businesses with no information about computer security offenders, by type of incident, 2005
cb05t10.csv	Table 10. Suspected computer security offenders' affiliation with business, by type of incident, 2005
cb05t11.csv	Table 11. Organizations to which computer security incidents were reported, by type of incident, 2005
cb05t12.csv	Table 12. Reasons businesses did not report incidents to law enforcement authorities, by type of incident, 2005
cb05t13.csv	Table 13. Networks most frequently accessed in computer security incidents, by type of incident, 2005
cb05t14.csv	Table 14. Sources of computer viruses, by business size, 2005
cb05t15.csv	Table 15. Most frequent computer security vulnerabilities, by type of incident, 2005
cb05t16.csv	Table 16. Detection of cyber attacks, by whether security was in-house or outsourced, 2005
cb05at01.csv	Appendix table 1. North American Industrial Classification System (NAICS) codes used in sample design, 2005
cb05at02.csv	Appendix table 2. National Computer Security Survey universe, sample, and response, by risk level and industry, 2005
cb05at03.csv	Appendix table 3. Use of computers and prevalence of computer security incidents, by risk level and industry, 2005
cb05at04.csv	Appendix table 4. Number of computer security incidents, by risk level and industry, 2005
cb05at05.csv	Appendix table 5. Monetary loss incurred from computer security incidents, by risk level and industry, 2005
cb05at06.csv	Appendix table 6. System downtime caused by computer security incidents, by risk level and industry, 2005
cb05at07.csv	Appendix table 7. Suspected offenders� affiliation with business, by risk level and industry, 2005
	 
